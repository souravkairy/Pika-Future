$(function(){			
    new CBPGridGallery( document.getElementById( 'grid-gallery' ) );
});