<?php

namespace App\Http\Controllers\backEnd;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use DB;
use Session; 


class adminAuth extends Controller
{
    public function index()
    {
        $header = view('Admin_auth/header');
        $footer = view('Admin_auth/footer');
        return view('Admin_auth/adminLoginForm')
            ->with('header', $header)
            ->with('footer', $footer);
    }
    public function forgotPass()
    {
        $header = view('Admin_auth/header');
        $footer = view('Admin_auth/footer');
        return view('Admin_auth/forgotPassword')
            ->with('header', $header)
            ->with('footer', $footer);

    }
    public function check_admin(request $request)
    {
        $this->validate($request,[
            'user_name' =>'required', 
            'password' =>'required' 
       ]);
        
       $user_name = $request->user_name;
       $password = $request->password;

       $db_ck = DB::table('admin_user')
                    ->where('user_name',$user_name)
                    ->where('user_password',md5($password))
                    ->where('status',1)
                    ->first();
        if ($db_ck) { 

            Session::put('user_name',$db_ck->user_name);
            Session::put('user_password',$db_ck->user_password);

            $notification = array(
                'message' => 'Welcome!! You are logged In',
                'alert-type' => 'success'
            );
            return Redirect('dashboard')->with($notification);
         }
         else
         {
            $notification = array(
                'message' => 'Wrong Username/Password, Please Try Again!!!',
                'alert-type' => 'error'
            );
            return Redirect('super_admin')->with($notification);
         }
        
    }
    public function log_out()
    {
        Session::put('user_name','');
    	Session::put('user_password','');
        $notification = array(
            'message' => 'log out successful',
            'alert-type' => 'info'
        );
        return Redirect::to('/super_admin')->with($notification);
    }
}
