<?php

namespace App\Http\Controllers\backEnd;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use DB;
use Session;

class backEnd extends Controller
{
    public function AuthCheck()
    {
        $admin_name = Session::get('user_name');
        $email = Session::get('user_password');

        if ($admin_name) {
            return;
        }
        else
        {
            return Redirect::to('/super_admin')->send();
        }
    }
    public function index()
    {
        $this->AuthCheck();
        $header = view('Admin_panel/header');
        $sidebar = view('Admin_panel/sidebar');
        $dashboard = view('Admin_panel/dashboard');
        $footer = view('Admin_panel/footer');
        return view('Admin_panel/master')
            ->with('header', $header)
            ->with('sidebar', $sidebar)
            ->with('dashboard', $dashboard)
            ->with('footer', $footer);

    }

    public function merchant_request()
    {

        $header = view('Admin_panel/header');
        // $sidebar = view('Admin_panel/sidebar');
        $dashboard = view('Admin_panel/merchant_request');
        $footer = view('Admin_panel/footer');
        return view('Admin_panel/master')
            ->with('header', $header)
            // ->with('sidebar', $sidebar)
            ->with('dashboard', $dashboard)
            ->with('footer', $footer);

    }

}
