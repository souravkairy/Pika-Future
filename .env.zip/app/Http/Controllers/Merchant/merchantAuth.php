<?php

namespace App\Http\Controllers\Merchant;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use DB;
use Session;


class merchantAuth extends Controller
{
    public function index()
    {
        $header = view('Admin_auth/header');
        $footer = view('Admin_auth/footer');
        return view('Merchant_auth/merchantLoginForm')
            ->with('header', $header)
            ->with('footer', $footer);
    }
    public function merchant_forgotPass()
    {
        $header = view('Admin_auth/header');
        $footer = view('Admin_auth/footer');
        return view('Admin_auth/forgotPassword')
            ->with('header', $header)
            ->with('footer', $footer);
    }
    public function check_merchant(request $request)
    {

        $this->validate($request,[
            'm_username' =>'required',
            'm_password' =>'required'
       ]);

       $m_username = $request->m_username;
       $m_password = $request->m_password;

       $db_ck = DB::table('merchant')
                    ->where('m_username',$m_username)
                    ->where('m_password',md5($m_password))
                    ->where('status',1)
                    ->first();
        if ($db_ck) {

            Session::put('id',$db_ck->id);
            Session::put('user_name',$db_ck->m_username);
            Session::put('user_password',$db_ck->m_password);

            $notification = array(
                'message' => 'Welcome!! You are logged In',
                'alert-type' => 'success'
            );
            return Redirect('merchant_dashboard')->with($notification);
         }
         else
         {
            $notification = array(
                'message' => 'Wrong Username/Password, Please Try Again!!!',
                'alert-type' => 'error'
            );
            return Redirect('merchant')->with($notification);
         }

    }
    public function merchantLogout()
    {
        Session::put('user_name','');
    	Session::put('user_password','');
        $notification = array(
            'message' => 'log out successful',
            'alert-type' => 'info'
        );
        return Redirect::to('/merchant')->with($notification);
    }
}
